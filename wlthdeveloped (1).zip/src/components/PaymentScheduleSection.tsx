import React, { useState } from "react";
import { formatValue, AmortizationRow } from "../utils";
import { CalculatorTool } from "../types";
import { Search } from "lucide-react";

interface PaymentScheduleSectionProps {
  schedule: { yearly: AmortizationRow[]; monthly: AmortizationRow[] };
  isDark: boolean;
  activeTool: CalculatorTool;
}

export default function PaymentScheduleSection({
  schedule,
  isDark,
  activeTool,
}: PaymentScheduleSectionProps) {
  const [scheduleTab, setScheduleTab] = useState<"yearly" | "monthly">("yearly");
  const [searchQuery, setSearchQuery] = useState("");

  const activeRows = scheduleTab === "yearly" ? schedule.yearly : schedule.monthly;
  
  // Optional search capability to jump to a specific period
  const filteredRows = searchQuery.trim()
    ? activeRows.filter((row) => row.period.toString().includes(searchQuery.trim()))
    : activeRows;

  const isLoan = ["mortgage", "debt_payoff"].includes(activeTool.tool_type);
  const prefix = activeTool.output_prefix || "$";
  const suffix = activeTool.output_suffix || "";

  return (
    <div 
      className="w-full mt-10 pt-8 border-t border-gray-500/15 dark:border-neutral-800/20 text-left" 
      id="payment-schedule-outer-panel"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-1">
            📊 Amortization & Repayment Schedule
          </span>
          <h3 className={`text-lg font-black tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>
            Amortization & Savings Schedule (Detailed Projection List)
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">
            Track the financial progression of your balances, interest accruals, and direct contributions over time.
          </p>
        </div>

        {/* Tab Selectors styled exactly with a premium interactive link layout */}
        <div className="flex items-center gap-6 font-mono text-xs font-bold" id="schedule-tabs-container">
          <button
            onClick={() => {
              setScheduleTab("yearly");
              setSearchQuery("");
            }}
            className={`pb-1 transition-all relative cursor-pointer ${
              scheduleTab === "yearly"
                ? "text-[#10B981] dark:text-[#00FF87] border-b-2 border-[#10B981] dark:border-[#00FF87] font-black"
                : "text-gray-400 hover:text-gray-300 border-b-2 border-transparent"
            }`}
          >
            Yearly
          </button>
          <button
            onClick={() => {
              setScheduleTab("monthly");
              setSearchQuery("");
            }}
            className={`pb-1 transition-all relative cursor-pointer ${
              scheduleTab === "monthly"
                ? "text-[#10B981] dark:text-[#00FF87] border-b-2 border-[#10B981] dark:border-[#00FF87] font-black"
                : "text-gray-400 hover:text-gray-300 border-b-2 border-transparent"
            }`}
          >
            Monthly
          </button>
        </div>
      </div>

      <div className={`p-5 rounded-3xl border ${isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-xs"}`} id="schedule-table-card">
        {/* Search header container */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4 pb-4 border-b border-gray-500/10">
          <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block font-bold">
            {scheduleTab === "yearly" ? "Annual Breakdown" : "Monthly Breakdown"} • {filteredRows.length} intervals found
          </span>
          
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={`Search ${scheduleTab === "yearly" ? "Year" : "Month"} (e.g. 5)...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full text-xs font-mono pl-9 pr-3 py-1.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-emerald-500 ${
                isDark 
                  ? "bg-neutral-900 border-[#2D2D30] text-gray-200 placeholder-gray-600 focus:border-[#00FF87]" 
                  : "bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400 focus:border-emerald-500"
              }`}
            />
          </div>
        </div>

        {/* Scrollable responsive table view */}
        <div className="overflow-x-auto max-h-[380px] overflow-y-auto scrollbar-thin scrollbar-thumb-emerald-500/20">
          <table className="w-full text-left font-mono text-[11px] border-collapse min-w-[600px]">
            <thead>
              <tr className={`border-b text-[9px] uppercase font-bold text-gray-400 ${isDark ? "border-[#1F1F22]" : "border-slate-100"}`}>
                <th className="pb-2.5 w-16">{scheduleTab === "yearly" ? "Year" : "Month"}</th>
                <th className="pb-2.5 text-right">Beginning Balance</th>
                <th className="pb-2.5 text-right">
                  {isLoan ? "Payment" : "Contribution"}
                </th>
                <th className="pb-2.5 text-right">
                  {isLoan ? "Interest Paid" : "Interest Earned"}
                </th>
                {isLoan && (
                  <th className="pb-2.5 text-right">Principal Paid</th>
                )}
                <th className="pb-2.5 text-right">Ending Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-500/5">
              {filteredRows.length > 0 ? (
                filteredRows.map((row) => (
                  <tr 
                    key={row.period} 
                    className={`transition-colors duration-150 ${isDark ? "hover:bg-neutral-900/40 text-gray-300" : "hover:bg-slate-50/50 text-slate-700"}`}
                  >
                    <td className="py-3 font-sans font-black text-gray-505 dark:text-neutral-400 pl-1">
                      {row.period}
                    </td>
                    <td className="py-3 text-right">
                      {formatValue(row.beginningBalance, prefix, suffix)}
                    </td>
                    <td className="py-3 text-right text-sky-500/90 font-bold">
                      {formatValue(row.payment, prefix, suffix)}
                    </td>
                    <td className="py-3 text-right text-rose-500/90">
                      {formatValue(row.interest, prefix, suffix)}
                    </td>
                    {isLoan && (
                      <td className="py-3 text-right text-emerald-500/90">
                        {formatValue(row.principalPaid, prefix, suffix)}
                      </td>
                    )}
                    <td className={`py-3 text-right font-bold ${isDark ? "text-white" : "text-slate-900"}`}>
                      {formatValue(row.endingBalance, prefix, suffix)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={isLoan ? 6 : 5} className="py-8 text-center text-gray-500">
                    No records found matching your period filter string.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
