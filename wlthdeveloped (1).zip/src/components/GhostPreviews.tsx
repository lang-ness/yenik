import React, { useState } from "react";
import { CalculatorTool } from "../types";
import { PREDEFINED_CALCULATORS } from "../data/predefinedCalcs";
import { 
  DollarSign, 
  Sparkles
} from "lucide-react";

interface GhostPreviewsProps {
  onSelectGhost: (tool: CalculatorTool) => void;
  searchTerm?: string;
  theme: "light" | "dark";
}

const CALCULATOR_GROUPS = [
  {
    id: "finance",
    label: "💰 Finance & Investment",
    icon: DollarSign,
    color: "text-emerald-500 border-emerald-500/20 bg-emerald-500/5",
    subgroups: [
      {
        title: "Mortgage & Property",
        items: [
          "Comprehensive Mortgage & Cost Analyzer"
        ]
      }
    ]
  }
];

export default function GhostPreviews({ onSelectGhost, searchTerm = "", theme }: GhostPreviewsProps) {
  const [filterText, setFilterText] = useState<string>("");

  const activeSearch = searchTerm || filterText;
  const isDark = theme === "dark";

  const handleItemClick = (itemName: string) => {
    // Directly activate the customized premium Mortgage Analyzer
    onSelectGhost(PREDEFINED_CALCULATORS[0]);
  };

  return (
    <div className="w-full flex flex-col gap-6" id="calculator-catalog-root">
      
      <div className="w-full flex flex-col gap-8" id="catalog-lists-container">
        {CALCULATOR_GROUPS.map((group) => {
          const matchedSubgroups = group.subgroups.map((sub) => {
            const matchedItems = sub.items.filter((item) =>
              item.toLowerCase().includes(activeSearch.toLowerCase())
            );
            return { ...sub, items: matchedItems };
          }).filter((sub) => sub.items.length > 0);

          if (matchedSubgroups.length === 0) return null;

          return (
            <div key={group.id} className="mb-8 font-sans animate-fade-in" id={`catalog-group-${group.id}`}>
              {/* Group Title */}
              <div className="flex items-center gap-2 mb-4 justify-center md:justify-start" id="catalog-group-title">
                <span className={`px-3.5 py-1.5 rounded-full text-xs font-bold border flex items-center gap-2 ${
                  isDark 
                    ? "bg-[#25252A]/40 border-[#2C2C35] " + group.color
                    : "bg-white border-slate-200 shadow-xs " + group.color
                }`}>
                  <group.icon className="w-4 h-4" />
                  {group.label}
                </span>
                <span className={`h-[1px] flex-grow hidden md:block ${isDark ? "bg-[#2C2C35]" : "bg-slate-200"}`}></span>
              </div>

              {/* Grid of Sub-groups */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="catalog-subgroups-grid">
                {matchedSubgroups.map((sub, sIdx) => (
                  <div 
                    key={sIdx} 
                    className={`p-5 rounded-3xl border transition-all ${
                      isDark 
                        ? "bg-[#1E1E22]/50 border-[#2C2C35] hover:border-[#2E2E36]" 
                        : "bg-white border-slate-200 hover:border-slate-350 shadow-xs hover:shadow-xs"
                    }`}
                  >
                    <h4 className={`text-[11px] font-mono font-bold uppercase tracking-widest mb-3.5 border-b pb-2 ${
                      isDark ? "text-gray-400 border-[#2E2E36]" : "text-slate-500 border-slate-200"
                    }`}>
                      {sub.title}
                    </h4>
                    
                    <div className="flex flex-wrap gap-1.5">
                      {sub.items.map((item, itemIdx) => (
                        <button
                          key={itemIdx}
                          onClick={() => handleItemClick(item)}
                          className={`text-xs font-medium px-3 py-2 rounded-xl transition-all border ${
                            isDark 
                              ? "bg-[#25252A] border-[#2E2E36] text-gray-300 hover:border-[#00FF87]/60 hover:text-[#00FF87]" 
                              : "bg-slate-50 border-slate-200 text-slate-700 hover:border-[#10B981] hover:text-[#10B981] hover:bg-white"
                          }`}
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Empty search fallback */}
        {activeSearch && CALCULATOR_GROUPS.every((g) => 
          g.subgroups.every((s) => s.items.filter((item) => item.toLowerCase().includes(activeSearch.toLowerCase())).length === 0)
        ) && (
          <div className={`text-center py-10 px-4 rounded-3xl border border-dashed ${
            isDark ? "bg-[#1E1E22]/30 border-[#2C2C35]" : "bg-slate-50 border-slate-250 text-slate-800"
          }`} id="catalog-empty-search">
            <Sparkles className={`w-8 h-8 mx-auto mb-3 animate-bounce ${isDark ? "text-[#00FF87]" : "text-[#10B981]"}`} />
            <h4 className="text-sm font-bold mb-1">Discover Custom Calculator</h4>
            <p className={`text-xs max-w-sm mx-auto ${isDark ? "text-gray-400" : "text-slate-500"}`}>
              Use the search bar to find or generate customized calculators dynamically.
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
