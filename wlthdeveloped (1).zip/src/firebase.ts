import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc,
  setDoc, 
  getDocs, 
  deleteDoc, 
  query, 
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import firebaseConfig from './firebase-applet-config.json';
import { CalculatorTool, CalculatorInput } from './types';

// Check if credentials have been provisioned and are not standard placeholders
const isFirebaseReady = 
  firebaseConfig && 
  firebaseConfig.apiKey && 
  firebaseConfig.apiKey !== "PLACEHOLDER_API_KEY" &&
  !firebaseConfig.apiKey.includes("PLACEHOLDER");

let app;
let db: any = null;
let auth: any = null;

if (isFirebaseReady) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    db = getFirestore(app);
    auth = getAuth(app);
  } catch (err) {
    console.error("Firebase init error, using local fallback mode:", err);
  }
}

// Simulated local storage user for smooth developer onboarding if Firebase project isn't active yet
const LOCAL_USER_KEY = "wlth-simulated-user";
const LOCAL_CALCS_KEY = "wlth-simulated-calcs";

export interface AppUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isSimulated?: boolean;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error Details: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// 1. Google Auth sign-in popup with simulation fallback
export async function signInWithGoogle(): Promise<AppUser> {
  if (isFirebaseReady && auth && db) {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      
      // Save/update user profile in firestore
      const user = result.user;
      const userRef = doc(db, 'users', user.uid);
      try {
        await setDoc(userRef, {
          userId: user.uid,
          displayName: user.displayName || 'Contributor',
          photoURL: user.photoURL || '',
          createdAt: serverTimestamp()
        }, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
      }

      return {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL
      };
    } catch (err: any) {
      if (err.message && err.message.includes('{"error"')) {
        throw err;
      }
      throw err;
    }
  } else {
    // Return high-fidelity mock user profile so user can test authentication immediately in the sandbox
    const mockUser: AppUser = {
      uid: "simulated_user_host_1337",
      email: "enemre2009@gmail.com",
      displayName: "Enes Emre (Simulated Preview)",
      photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
      isSimulated: true
    };
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(mockUser));
    return mockUser;
  }
}

// 1.5 Sign in using simulation fallback explicitly
export async function signInWithGoogleSimulated(): Promise<AppUser> {
  const mockUser: AppUser = {
    uid: "simulated_user_host_1337",
    email: "enemre2009@gmail.com",
    displayName: "Enes Emre (Simülasyon)",
    photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
    isSimulated: true
  };
  localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(mockUser));
  return mockUser;
}

// 2. Clear authorization or simulation active session
export async function logOut(): Promise<void> {
  if (isFirebaseReady && auth) {
    await signOut(auth);
  } else {
    localStorage.removeItem(LOCAL_USER_KEY);
  }
}

// 3. Keep account session state in-sync
export function subscribeAuthState(callback: (user: AppUser | null) => void) {
  if (isFirebaseReady && auth) {
    return onAuthStateChanged(auth, async (firebaseUser: User | null) => {
      if (firebaseUser) {
        callback({
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName,
          photoURL: firebaseUser.photoURL
        });
      } else {
        callback(null);
      }
    });
  } else {
    // Local storage subscription
    const getLocal = () => {
      const stored = localStorage.getItem(LOCAL_USER_KEY);
      if (stored) {
        try {
          return JSON.parse(stored) as AppUser;
        } catch {
          return null;
        }
      }
      return null;
    };
    // Emit initial
    callback(getLocal());
    
    // Poll storage for updates to keep simulated login synced
    const interval = setInterval(() => {
      callback(getLocal());
    }, 1000);
    return () => clearInterval(interval);
  }
}

export interface SavedCalculationItem {
  calcId: string;
  userId: string;
  title: string;
  description: string;
  tool_type: string;
  inputs: Record<string, any>;
  inputs_schema?: CalculatorInput[];
  formula: string;
  output_label: string;
  output_prefix: string;
  output_suffix: string;
  chart_type: string;
  insight: string;
  createdAt: string;
}

// 4. Save calculations associated with active user
export async function saveCalculationToUser(
  user: AppUser,
  tool: CalculatorTool,
  inputs: Record<string, any>
): Promise<void> {
  const calcId = `calc_${tool.tool_type}_${Date.now()}`;
  
  const payload: SavedCalculationItem = {
    calcId,
    userId: user.uid,
    title: tool.title,
    description: tool.description,
    tool_type: tool.tool_type,
    inputs: inputs,
    inputs_schema: tool.inputs,
    formula: tool.formula,
    output_label: tool.output_label || "Calculated Balance Outcome",
    output_prefix: tool.output_prefix || "",
    output_suffix: tool.output_suffix || "",
    chart_type: tool.chart_type,
    insight: tool.insight,
    createdAt: new Date().toISOString()
  };

  if (isFirebaseReady && db && !user.isSimulated) {
    const path = `users/${user.uid}/saved_calculations/${calcId}`;
    try {
      const docRef = doc(db, 'users', user.uid, 'saved_calculations', calcId);
      await setDoc(docRef, {
        ...payload,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  } else {
    // Simulated local storage backend saving
    const storedStr = localStorage.getItem(LOCAL_CALCS_KEY);
    let items: SavedCalculationItem[] = [];
    if (storedStr) {
      try { items = JSON.parse(storedStr); } catch { items = []; }
    }
    // Prepend new history entry
    items.unshift(payload);
    // Prune standard list length to keep localStorage tidy
    if (items.length > 50) items = items.slice(0, 50);
    localStorage.setItem(LOCAL_CALCS_KEY, JSON.stringify(items));
  }
}

// 5. Retrieve saved calculations for active user
export async function getSavedCalculations(user: AppUser): Promise<SavedCalculationItem[]> {
  if (isFirebaseReady && db && !user.isSimulated) {
    const path = `users/${user.uid}/saved_calculations`;
    try {
      const collRef = collection(db, 'users', user.uid, 'saved_calculations');
      const snapshot = await getDocs(collRef);
      const list: SavedCalculationItem[] = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        let dateStr = new Date().toISOString();
        if (data.createdAt) {
          if (typeof data.createdAt.toDate === 'function') {
            dateStr = data.createdAt.toDate().toISOString();
          } else if (typeof data.createdAt === 'string') {
            dateStr = data.createdAt;
          } else if (data.createdAt.seconds) { // raw timestamp representation if plain object
            dateStr = new Date(data.createdAt.seconds * 1000).toISOString();
          }
        }
        list.push({
          ...data,
          createdAt: dateStr
        } as SavedCalculationItem);
      });
      // Sort descending by createdAt
      return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, path);
    }
  } else {
    const storedStr = localStorage.getItem(LOCAL_CALCS_KEY);
    if (storedStr) {
      try {
        const items = JSON.parse(storedStr) as SavedCalculationItem[];
        return items.filter(item => item.userId === user.uid);
      } catch {
        return [];
      }
    }
    return [];
  }
}

// 6. Delete item from calculations history
export async function deleteSavedCalculation(user: AppUser, calcId: string): Promise<void> {
  if (isFirebaseReady && db && !user.isSimulated) {
    const path = `users/${user.uid}/saved_calculations/${calcId}`;
    try {
      const docRef = doc(db, 'users', user.uid, 'saved_calculations', calcId);
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  } else {
    const storedStr = localStorage.getItem(LOCAL_CALCS_KEY);
    if (storedStr) {
      try {
        let items = JSON.parse(storedStr) as SavedCalculationItem[];
        items = items.filter(item => item.calcId !== calcId);
        localStorage.setItem(LOCAL_CALCS_KEY, JSON.stringify(items));
      } catch {
        // failed silently
      }
    }
  }
}

/**
 * Base64 helper for offline or quick-link compression.
 * Safely encodes unicode characters (e.g. Turkish) using encodeURIComponent.
 */
export function encodeCalculatorToUrl(tool: CalculatorTool): string {
  try {
    const rawJson = JSON.stringify(tool);
    const encoded = btoa(encodeURIComponent(rawJson).replace(/%([0-9A-F]{2})/g, (_, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    }));
    return encoded;
  } catch (err) {
    console.error("Failed to encode calculator data:", err);
    return "";
  }
}

/**
 * Decodes the base64 string from URL back to CalculatorTool.
 */
export function decodeCalculatorFromUrl(base64Str: string): CalculatorTool | null {
  try {
    if (!base64Str) return null;
    const decoded = decodeURIComponent(atob(base64Str).split('').map((c) => {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(decoded) as CalculatorTool;
  } catch (err) {
    console.warn("Failed to decode calculator data from URL:", err);
    return null;
  }
}

/**
 * Generates an alphanumeric 6-character random short code.
 */
function generateShortCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Saves a shared calculator globally. If Firebase is ready, writes to Firestore.
 * Otherwise, generates a local-storage mock entry and returns a short code or base64 fallback.
 */
export async function saveSharedCalculator(tool: CalculatorTool): Promise<string> {
  const shortCode = generateShortCode();
  const payload = {
    ...tool,
    id: tool.id || `custom_${Date.now()}`,
    createdAt: new Date().toISOString()
  };

  if (isFirebaseReady && db) {
    try {
      const docRef = doc(db, 'shared_calculators', shortCode);
      await setDoc(docRef, payload);
      return shortCode;
    } catch (err) {
      console.warn("Firestore shared write failed, falling back to URL base64:", err);
    }
  }

  // Backup fallback: save locally if in offline/sandbox preview
  const localShares = localStorage.getItem("wlth-shared-calculators") || "{}";
  try {
    const parsed = JSON.parse(localShares);
    parsed[shortCode] = payload;
    localStorage.setItem("wlth-shared-calculators", JSON.stringify(parsed));
  } catch (ex) {
    console.error("Local shares serialization failed", ex);
  }

  return shortCode;
}

/**
 * Retrieves a shared calculator from Firestore or localStorage.
 */
export async function getSharedCalculator(shortCode: string): Promise<CalculatorTool | null> {
  if (!shortCode) return null;

  if (isFirebaseReady && db) {
    try {
      const docRef = doc(db, 'shared_calculators', shortCode);
      const snapshot = await getDoc(docRef);
      if (snapshot.exists()) {
        const data = snapshot.data();
        return data as CalculatorTool;
      }
    } catch (err) {
      console.warn("Firestore shared fetch failed:", err);
    }
  }

  // Fallback to local shares if present
  const localShares = localStorage.getItem("wlth-shared-calculators");
  if (localShares) {
    try {
      const parsed = JSON.parse(localShares);
      if (parsed[shortCode]) {
        return parsed[shortCode] as CalculatorTool;
      }
    } catch {
      // ignore
    }
  }

  return null;
}
