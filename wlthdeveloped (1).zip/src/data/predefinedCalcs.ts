import { CalculatorTool } from "../types";

export const PREDEFINED_CALCULATORS: CalculatorTool[] = [
  {
    tool_type: "mortgage",
    title: "Comprehensive Mortgage & Cost Analyzer",
    description: "Analyze monthly mortgage payments, property taxes, home insurance premiums, and lifetime amortization breakdowns.",
    inputs: [
      {
        id: "price",
        label: "Home Price",
        type: "slider",
        default: 400000,
        prefix: "$",
        min: 50000,
        max: 2000000,
        step: 5000
      },
      {
        id: "down",
        label: "Down Payment",
        type: "slider",
        default: 20,
        suffix: "%",
        min: 0,
        max: 80,
        step: 1
      },
      {
        id: "years",
        label: "Loan Term",
        type: "slider",
        default: 30,
        suffix: " years",
        min: 5,
        max: 40,
        step: 1
      },
      {
        id: "rate",
        label: "Interest Rate",
        type: "slider",
        default: 6.576,
        suffix: "%",
        min: 0.1,
        max: 20,
        step: 0.001
      },
      {
        id: "include_costs",
        label: "Include Taxes & Costs Below",
        type: "slider",
        default: 0, // Starts off / closed
        min: 0,
        max: 1,
        step: 1,
        suffix: ""
      },
      {
        id: "property_taxes",
        label: "Property Taxes",
        type: "slider",
        default: 1.2,
        suffix: "%",
        min: 0,
        max: 5,
        step: 0.05
      },
      {
        id: "home_insurance",
        label: "Home Insurance (Annual)",
        type: "slider",
        default: 1500,
        prefix: "$",
        min: 0,
        max: 10000,
        step: 100
      },
      {
        id: "pmi_insurance",
        label: "PMI Insurance (Annual)",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 5000,
        step: 50
      },
      {
        id: "hoa_fee",
        label: "HOA Fee (Monthly)",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 2000,
        step: 10
      },
      {
        id: "other_costs",
        label: "Other Costs (Annual)",
        type: "slider",
        default: 4000,
        prefix: "$",
        min: 0,
        max: 20000,
        step: 100
      }
    ],
    formula: "price * (1 - down / 100) * ((rate/100/12) * pow(1 + (rate/100/12), years * 12)) / (pow(1 + (rate/100/12), years * 12) - 1)",
    output_label: "Estimated Monthly Principal & Interest Payment",
    output_prefix: "$",
    chart_type: "distribution", // Defaults to dynamic Donut Chart breakdown!
    insight: "Your property tax, home insurance, and recurring expenses add up to your total out-of-pocket obligation. Consider making a 20% down payment to avoid extra borrowing costs."
  },
  {
    tool_type: "budget", // Matches budget layout or custom loss tracking
    id: "loss_tracker",
    title: "Daily Loss & Recurring Cumulative Tracker",
    description: "Analyze daily financial leaks or trading losses and visualize cumulative impacts over weeks, months, and years in a single unified donut view.",
    inputs: [
      {
        id: "daily_loss",
        label: "Daily Financial Loss / Leakage",
        type: "slider",
        default: 400,
        prefix: "$",
        min: 1,
        max: 10000,
        step: 10
      },
      {
        id: "active_days",
        label: "Trading/Loss Days per Year",
        type: "slider",
        default: 365,
        suffix: " days",
        min: 1,
        max: 365,
        step: 1
      },
      {
        id: "other_loss",
        label: "Other Monthly Leakages",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 5000,
        step: 50
      }
    ],
    formula: "daily_loss * 30 + other_loss",
    output_label: "Total Collective Monthly Leakage",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "Evaluating daily financial drains helps identify recurring leaks. Compounding daily losses over a year uncovers the substantial long-term cumulative impact."
  }
];

export function findMatchingPredefinedCalculator(query: string): CalculatorTool | null {
  const q = query.toLowerCase().trim();
  if (!q) return null;

  // Detect loss / leakage / spending questions
  if (
    q.includes("lose") ||
    q.includes("lost") ||
    q.includes("spend") ||
    q.includes("cost") ||
    q.includes("waste") ||
    q.includes("leak") ||
    q.includes("kayıp") ||
    q.includes("kayip") ||
    q.includes("zarar") ||
    q.includes("harcama") ||
    q.includes("gider")
  ) {
    // Try to extract numerical values from the prompt to inject custom starting default values
    const numMatch = q.match(/\b\d+(\.\d+)?\b/);
    if (numMatch) {
      const parsedVal = Number(numMatch[0]);
      if (parsedVal > 0) {
        // We override the default input value of daily_loss inside PREDEFINED_CALCULATORS[1] dynamically
        PREDEFINED_CALCULATORS[1].inputs[0].default = parsedVal;
      }
    }
    return PREDEFINED_CALCULATORS[1];
  }

  // Detect mortgage / home / property calculations
  if (
    q.includes("mortgage") ||
    q.includes("home") ||
    q.includes("house") ||
    q.includes("property") ||
    q.includes("loan") ||
    q.includes("ev") ||
    q.includes("konut") ||
    q.includes("kredi") ||
    q.includes("mülk")
  ) {
    return PREDEFINED_CALCULATORS[0];
  }

  // Default fallback
  return PREDEFINED_CALCULATORS[0];
}
